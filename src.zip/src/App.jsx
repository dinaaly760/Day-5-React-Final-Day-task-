
import "./App.css";
import { MyNav } from "./Components/MyNav";
import { Route, Routes } from "react-router-dom";
import { Home } from "./Components/Home";
import { Products } from "./Components/Products";
import { ProductDetails } from "./Components/ProductDetails";
import { ProductForm } from "./Components/ProductForm";
import { NotFound } from "./Components/NotFound";
import MySlider from "./Components/Myslider";
import MyFooter from "./Components/MyFooter";

function App() {
	return (
		<div>
			<MyNav />
			<Routes>
				<Route path='' element={<Home />} />
				<Route path='home' element={<Home />} />
				<Route path='products' element={<Products />} />
				<Route path='products/:id' element={<ProductDetails />} />
				<Route path='products/:id/edit' element={<ProductForm />} />
				<Route path='*' element={<NotFound />} />
			</Routes>
             <MyFooter></MyFooter>
		</div>
	);
}

export default App;