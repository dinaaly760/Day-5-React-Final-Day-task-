import React from "react";
import MySlider from "./Myslider";

export function Home() {
	return (
		<div className='alert alert-info text-center'>
			<MySlider></MySlider>
			
		</div>
	);
}