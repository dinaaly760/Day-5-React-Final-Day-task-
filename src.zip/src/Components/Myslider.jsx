import React from 'react'
import { Carousel } from 'react-bootstrap'

export default function MySlider() {
  return (
    <div>
          <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100 customImg"
          src="https://images.pexels.com/photos/1323206/pexels-photo-1323206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>Chapter one</h3>
          <p>Love yourself</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100 customImg"
          src="https://images.pexels.com/photos/206388/pexels-photo-206388.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="Second slide"
        />

        <Carousel.Caption>
          <h3>chapter 2</h3>
          <p>achieve your goals </p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100 customImg"
          src="https://images.pexels.com/photos/1314584/pexels-photo-1314584.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="Third slide"
        />
        </Carousel.Item>
        <Carousel.Item>
        <img
          className="d-block w-100 customImg"
          src="https://images.pexels.com/photos/268941/pexels-photo-268941.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1 "
          alt="Fourth slide"
        />
      </Carousel.Item>
    </Carousel>
    </div>
  )
}