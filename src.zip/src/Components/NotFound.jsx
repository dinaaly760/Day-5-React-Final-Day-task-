import React from "react";

export function NotFound() {
	return (
		<div className='bg-light p-5 text-center'>
			<h1 className=''>404 Not Found Page</h1>
		</div>
	);
}